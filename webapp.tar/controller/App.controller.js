sap.ui.define(
    [
        "sap/ui/core/mvc/Controller"
    ],
    function(BaseController) {
      "use strict";
  
      return BaseController.extend("com.demo.empapp.controller.App", {
        onInit: function() {
        }
      });
    }
  );
  