/* global QUnit */

sap.ui.require(["com/demo/empapp/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
