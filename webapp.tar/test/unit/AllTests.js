sap.ui.define([
	"comdemo/emp_app/test/unit/controller/View1.controller"
], function () {
	"use strict";
});
